<?php
$postFile = 'posts.json';
$userFile = 'users.json';
if (!file_exists($postFile)) file_put_contents($postFile, json_encode([]));
if (!file_exists($userFile)) file_put_contents($userFile, json_encode([]));
$posts = json_decode(file_get_contents($postFile), true);
$users = json_decode(file_get_contents($userFile), true);

if (isset($_POST['action']) && $_POST['action'] == 'register') {
    $username = '@' . preg_replace('/[^a-zA-Z0-9]/', '', $_POST['username']);
    $newUser = ['username' => $username, 'avatar' => 'https://i.pravatar.cc/150?u=' . time()];
    $users[] = $newUser;
    file_put_contents($userFile, json_encode($users));
    setcookie('current_user', $username, time() + (86400 * 30), "/");
    header("Location: index.php"); exit();
}

if (isset($_POST['action']) && $_POST['action'] == 'post') {
    $userTag = $_COOKIE['current_user'] ?? '@guest';
    $type = $_POST['type'] ?? 'image';
    $img = $_POST['img_data'];
    $vid = $_POST['video_link'] ?? '';
    $youtube_id = null;
    if ($type == 'video' && !empty($vid)) {
        preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $vid, $match);
        $youtube_id = $match[1] ?? '';
        $img = "https://img.youtube.com/vi/$youtube_id/maxresdefault.jpg";
    }
    $newPost = [
        'id' => time(), 
        'type' => $type, 
        'title' => htmlspecialchars($_POST['title']), 
        'content' => htmlspecialchars($_POST['content'] ?? ''), 
        'image' => $img, 
        'video_id' => $youtube_id, 
        'user' => $userTag, 
        'date' => date('H:i, d/m')
    ];
    array_unshift($posts, $newPost);
    file_put_contents($postFile, json_encode($posts));
    header("Location: index.php"); exit();
}
?>
<?php include_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="manifest" href="manifest.json">
    
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="Loop">
    <link rel="apple-touch-icon" href="https://i.postimg.cc/wBLTztJN/image.png">
    <meta name="theme-color" content="#4158D0">
    <title>Loop App</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <style>
        :root { --p: #4158D0; --bg: #f8f9fb; --text: #1a1a1a; --sub: #8e8e93; --radius: 28px; }
        * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; outline: none; }
        body { background: var(--bg); font-family: 'Plus Jakarta Sans', sans-serif; margin: 0; color: var(--text); padding-bottom: 120px; overflow-x: hidden; }
        
        header { padding: 20px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 1000; background: rgba(248,249,251,0.9); backdrop-filter: blur(15px); }
        .logo { font-size: 26px; font-weight: 800; color: var(--p); letter-spacing: -1px; }
        .header-btns { display: flex; gap: 15px; align-items: center; }
        .menu-icon { font-size: 24px; cursor: pointer; padding: 5px; }

        /* Fix Overlay Visibility */
        .overlay { position: fixed; inset: 0; background: #fff; z-index: -1; opacity: 0; display: none; padding: 30px 20px; overflow-y: auto; transition: opacity 0.3s; }
        .overlay.active { display: block; z-index: 9999; opacity: 1; }
        .close { font-size: 35px; cursor: pointer; margin-bottom: 20px; display: inline-block; line-height: 1; }

        /* Home Content */
        .horizontal-scroll { display: flex; gap: 15px; overflow-x: auto; padding: 0 15px 20px; scrollbar-width: none; position: relative; z-index: 10; }
        .horizontal-scroll::-webkit-scrollbar { display: none; }
        .member-card { min-width: 75px; text-align: center; flex-shrink: 0; cursor: pointer; pointer-events: auto; }
        .member-card .avatar-ring { width: 70px; height: 70px; border-radius: 50%; padding: 3px; background: linear-gradient(45deg, #f09433, #bc1888); margin-bottom: 5px; }
        .member-card img { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; border: 3px solid #fff; }
        
        .container { padding: 0 15px; position: relative; z-index: 10; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .card { background: #fff; border-radius: var(--radius); overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.02); position: relative; cursor: pointer; }
        .img-box { width: 100%; aspect-ratio: 1/1.2; position: relative; background: #eee; }
        .img-box img { width: 100%; height: 100%; object-fit: cover; }
        .user-tag { position: absolute; top: 10px; left: 10px; background: rgba(0,0,0,0.4); color: #fff; padding: 4px 10px; border-radius: 20px; font-size: 9px; backdrop-filter: blur(8px); }
        .info { padding: 12px; }
        .info h3 { font-size: 13px; margin: 0; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

        /* Navigation */
        .nav { position: fixed; bottom: 25px; left: 50%; transform: translateX(-50%); width: 85%; max-width: 400px; background: rgba(255,255,255,0.95); backdrop-filter: blur(20px); height: 65px; border-radius: 35px; display: flex; justify-content: space-around; align-items: center; box-shadow: 0 10px 30px rgba(0,0,0,0.1); z-index: 2000; }
        .nav-btn { font-size: 22px; cursor: pointer; opacity: 0.6; }
        
        /* Fix Add Button Center */
        .add-btn { width: 55px; height: 55px; background: var(--p); color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 32px; margin-top: -25px; font-weight: 400; border: 4px solid var(--bg); padding-bottom: 4px; }

        /* Forms & Tabs */
        .neu-input { width: 100%; padding: 16px; border-radius: 18px; border: none; background: #f0f2f5; margin-bottom: 15px; font-size: 16px; font-family: inherit; }
        .btn-main { width: 100%; padding: 18px; border-radius: 18px; border: none; background: var(--p); color: #fff; font-weight: 700; cursor: pointer; }
        .tabs { display: flex; gap: 10px; margin-bottom: 20px; background: #f0f2f5; padding: 5px; border-radius: 15px; }
        .tab { flex: 1; padding: 10px; text-align: center; border-radius: 12px; font-weight: 600; cursor: pointer; }
        .tab.active { background: #fff; color: var(--p); box-shadow: 0 2px 5px rgba(0,0,0,0.05); }

        .blog-item { margin-bottom: 25px; background: #fff; border-radius: var(--radius); overflow: hidden; }
        .video-container { width: 100%; aspect-ratio: 16/9; background: #000; }
        .video-container iframe { width: 100%; height: 100%; border: none; }
        /* Thêm vào trong thẻ <style> */
* {
    /* Ngăn bôi đen văn bản */
    -webkit-user-select: none; /* Safari */
    -ms-user-select: none;      /* Internet Explorer/Edge */
    user-select: none;          /* Thẻ tiêu chuẩn (Chrome, Firefox) */
    
    /* Các thuộc tính bạn đã có sẵn */
    box-sizing: border-box; 
    -webkit-tap-highlight-color: transparent; 
    outline: none; 
}

/* Nếu bạn muốn người dùng vẫn có thể nhập liệu vào ô Input hoặc Textarea */
input, textarea {
    -webkit-user-select: text;
    -ms-user-select: text;
    user-select: text;
}
    </style>
</head>
<body>

<header>
    <div class="logo">Loop</div>
    <div class="header-btns">
        <div style="font-size: 22px; cursor:pointer;">🔔</div>
        <div class="menu-icon" onclick="show('menuPopup')">☰</div>
    </div>
</header>

<div id="menuPopup" class="overlay">
    <span class="close" onclick="hide('menuPopup')">×</span>
    <h2>Khám phá</h2>
    <div style="display: flex; flex-direction: column; gap: 10px;">
        <a href="task.php" style="text-decoration:none; color:inherit;">
            <div style="padding: 18px; background: #f0f2f5; border-radius: 18px; font-weight: 600; display: flex; align-items: center; gap: 12px;">
                <span>📋</span> Lịch trình công việc
            </div>
        </a>

        <a href="taimp3.php" style="text-decoration:none; color:inherit;">
            <div style="padding: 18px; background: #f0f2f5; border-radius: 18px; font-weight: 600; display: flex; align-items: center; gap: 12px;">
                <span>🎵</span> Tải audio Youtube
            </div>
        </a>
        
        <div onclick="hide('menuPopup'); show('videoPage')" style="padding: 18px; background: #f0f2f5; border-radius: 18px; font-weight: 600; display: flex; align-items: center; gap: 12px; cursor: pointer;">
            <span>🎬</span> Video Feed
        </div>
        
        <div onclick="hide('menuPopup'); show('userOverlay')" style="padding: 18px; background: #f0f2f5; border-radius: 18px; font-weight: 600; display: flex; align-items: center; gap: 12px; cursor: pointer;">
            <span>👤</span> Tài khoản cá nhân
        </div>
    </div>
</div>

<div id="homePage">
    <div class="top-section">
        <h2 style="font-size: 18px; margin: 10px 15px 15px;">Members</h2>
        <div class="horizontal-scroll">
            <?php foreach($users as $u): ?>
            <div class="member-card" onclick="openMemberPosts('<?php echo $u['username']; ?>')">
                <div class="avatar-ring"><img src="<?php echo $u['avatar']; ?>"></div>
                <span><?php echo $u['username']; ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="container">
        <h2 style="font-size: 18px; margin-bottom: 15px;">Explore</h2>
        <div class="grid" id="mainGrid">
            <?php foreach($posts as $p): ?>
            <div class="card" onclick='openDetail(<?php echo json_encode($p); ?>)'>
                <div class="img-box">
                    <span class="user-tag"><?php echo $p['user']; ?></span>
                    <img src="<?php echo $p['image']; ?>">
                </div>
                <div class="info"><h3><?php echo $p['title']; ?></h3></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div id="videoPage" class="overlay">
    <span class="close" onclick="hide('videoPage')">×</span>
    <h2>Loop Video Feed</h2>
    <div id="videoBlogList">
        <?php foreach($posts as $p): if($p['type'] == 'video'): ?>
            <div class="blog-item">
                <div class="video-container"><iframe src="https://www.youtube.com/embed/<?php echo $p['video_id']; ?>" allowfullscreen></iframe></div>
                <div class="info"><b style="color: var(--p);"><?php echo $p['user']; ?></b><h3><?php echo $p['title']; ?></h3></div>
            </div>
        <?php endif; endforeach; ?>
    </div>
</div>

<div id="postOverlay" class="overlay">
    <span class="close" onclick="hide('postOverlay')">×</span>
    <div class="tabs">
        <div class="tab active" onclick="switchTab('image', this)">📸 Ảnh</div>
        <div class="tab" onclick="switchTab('video', this)">🎬 Video</div>
    </div>
    <form method="POST">
        <input type="hidden" name="action" value="post">
        <input type="hidden" name="type" id="post_type" value="image">
        <div id="image_fields">
            <input type="hidden" name="img_data" id="img_data">
            <div id="drop-zone" onclick="document.getElementById('file-input').click()" style="height:150px; background:#f0f2f5; border-radius:20px; display:flex; align-items:center; justify-content:center; border:2px dashed #ccc; color:#888;">Chọn hoặc dán ảnh</div>
            <input type="file" id="file-input" style="display:none" onchange="preview(this)">
        </div>
        <div id="video_fields" style="display:none;">
            <input type="text" name="video_link" class="neu-input" placeholder="Dán link Youtube...">
        </div>
        <input type="text" name="title" class="neu-input" placeholder="Tiêu đề..." required>
        <textarea name="content" class="neu-input" rows="3" placeholder="Mô tả..."></textarea>
        <button class="btn-main">Chia sẻ ngay</button>
    </form>
</div>

<div id="detailView" class="overlay">
    <span class="close" onclick="hide('detailView')">×</span>
    <div id="detMedia"></div>
    <h1 id="detTitle" style="margin: 15px 0 5px;"></h1>
    <b id="detUser" style="color:var(--p)"></b>
    <p id="detContent" style="white-space:pre-wrap; margin-top:15px; line-height:1.6; color:#444;"></p>
</div>

<div id="userOverlay" class="overlay">
    <span class="close" onclick="hide('userOverlay')">×</span>
    <h2>Tài khoản</h2>
    <?php if(!isset($_COOKIE['current_user'])): ?>
    <form method="POST">
        <input type="hidden" name="action" value="register">
        <input type="text" name="username" class="neu-input" placeholder="Nhập tên của bạn..." required>
        <button class="btn-main">Đăng ký tham gia</button>
    </form>
    <?php else: ?>
    <div style="text-align:center; padding: 20px;">
        <div style="font-size: 50px;">👤</div>
        <h3><?php echo $_COOKIE['current_user']; ?></h3>
        <p style="color:var(--sub)">Chào mừng bạn quay trở lại!</p>
    </div>
    <?php endif; ?>
</div>

<div id="memberPostsView" class="overlay">
    <span class="close" onclick="hide('memberPostsView')">×</span>
    <h2 id="memberNameTitle"></h2>
    <div id="memberPostsGrid" class="grid"></div>
</div>

<nav class="nav">
    <div class="nav-btn" onclick="location.reload()">🏠</div>
    <div class="nav-btn">🔍</div>
    <div class="add-btn" onclick="show('postOverlay')">+</div>
    <div class="nav-btn" onclick="show('videoPage')">🎬</div>
    <div class="nav-btn" onclick="show('userOverlay')">👤</div>
</nav>
<script>
    // Chặn chuột phải
    document.addEventListener('contextmenu', event => event.preventDefault());

    // Chặn một số phím tắt phổ biến để soi code (F12, Ctrl+Shift+I)
    document.onkeydown = function(e) {
        if(e.keyCode == 123) return false; // F12
        if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) return false;
        if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) return false;
        if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) return false;
        if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) return false;
    }
</script>
<script>
    
    const allPosts = <?php echo json_encode($posts); ?>;

    function show(id) {
        const el = document.getElementById(id);
        el.style.display = 'block';
        setTimeout(() => el.classList.add('active'), 10);
        document.body.style.overflow = 'hidden';
    }

    function hide(id) {
        const el = document.getElementById(id);
        el.classList.remove('active');
        setTimeout(() => {
            el.style.display = 'none';
            // Chỉ mở lại scroll nếu không còn overlay nào mở
            if(!document.querySelector('.overlay.active')) {
                document.body.style.overflow = 'auto';
            }
        }, 300);
    }

    function switchTab(type, el) {
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        el.classList.add('active');
        document.getElementById('post_type').value = type;
        document.getElementById('image_fields').style.display = type === 'image' ? 'block' : 'none';
        document.getElementById('video_fields').style.display = type === 'video' ? 'block' : 'none';
    }

    function preview(input) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = (e) => {
                document.getElementById('drop-zone').innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover;border-radius:18px;">`;
                document.getElementById('img_data').value = e.target.result;
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

    function openDetail(data) {
        const mediaBox = document.getElementById('detMedia');
        if(data.type === 'video') {
            mediaBox.innerHTML = `<div class="video-container"><iframe src="https://www.youtube.com/embed/${data.video_id}" allowfullscreen></iframe></div>`;
        } else {
            mediaBox.innerHTML = `<img src="${data.image}" style="width:100%; border-radius:20px; box-shadow:0 10px 20px rgba(0,0,0,0.1);">`;
        }
        document.getElementById('detTitle').innerText = data.title;
        document.getElementById('detUser').innerText = data.user;
        document.getElementById('detContent').innerText = data.content;
        show('detailView');
    }

    function openMemberPosts(username) {
        const filtered = allPosts.filter(p => p.user === username);
        const grid = document.getElementById('memberPostsGrid');
        document.getElementById('memberNameTitle').innerText = "Bài viết của " + username;
        grid.innerHTML = filtered.map(p => `
            <div class="card" onclick='openDetail(${JSON.stringify(p)})'>
                <div class="img-box"><img src="${p.image}"></div>
                <div class="info"><h3>${p.title}</h3></div>
            </div>
        `).join('');
        show('memberPostsView');
    }

    // Xử lý dán ảnh từ Clipboard
    window.onpaste = (e) => {
        const item = e.clipboardData.items[0];
        if (item && item.type.includes('image')) {
            const reader = new FileReader();
            reader.onload = (ev) => {
                document.getElementById('drop-zone').innerHTML = `<img src="${ev.target.result}" style="width:100%;height:100%;object-fit:cover;border-radius:18px;">`;
                document.getElementById('img_data').value = ev.target.result;
            };
            reader.readAsDataURL(item.getAsFile());
        }
    };
</script>
</body>
</html>
const CACHE_NAME = 'blog-speed-v7';
const RESET_INTERVAL = 80 * 1000; // 1 phút 20 giây

// Danh sách các file trong folder blog cần cache
const BLOG_FILES = [
  './', 
  'index.php',
  'config.php'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      // Dùng map để cache từng file, lỗi file này vẫn chạy file kia
      return Promise.allSettled(
        BLOG_FILES.map(url => cache.add(url))
      );
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  // Buộc Service Worker chiếm quyền điều khiển ngay lập tức trong folder blog
  event.waitUntil(clients.claim());
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      // Nếu có trong cache, trả về luôn (tốc độ siêu cấp)
      if (cached) return cached;

      // Nếu không, tải từ mạng và lưu lại cho lần sau
      return fetch(event.request).then((response) => {
        if (response.status === 200) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        }
        return response;
      });
    })
  );
});

// Reset cache mỗi 80 giây
setInterval(async () => {
  const keys = await caches.keys();
  for (let key of keys) {
    await caches.delete(key);
  }
  console.log('♻️ Blog Cache đã được làm mới!');
}, RESET_INTERVAL);
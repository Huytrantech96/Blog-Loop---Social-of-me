<?php
// Cấu hình mật khẩu truy cập admin đơn giản
$admin_password = "123"; // Hãy đổi mật khẩu này
$is_logged_in = false;

// Kiểm tra đăng nhập qua session hoặc form
session_start();
if (isset($_POST['login_pass']) && $_POST['login_pass'] == $admin_password) {
    $_SESSION['admin_logged'] = true;
}

if (isset($_SESSION['admin_logged']) && $_SESSION['admin_logged'] == true) {
    $is_logged_in = true;
}

$postFile = 'posts.json';
$posts = file_exists($postFile) ? json_decode(file_get_contents($postFile), true) : [];

// Xử lý xóa bài viết
if ($is_logged_in && isset($_GET['delete_id'])) {
    $deleteId = $_GET['delete_id'];
    $posts = array_filter($posts, function($post) use ($deleteId) {
        return $post['id'] != $deleteId;
    });
    // Reset index mảng và lưu lại
    file_put_contents($postFile, json_encode(array_values($posts)));
    header("Location: admin.php?status=deleted");
    exit();
}

// Xử lý đăng xuất
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản trị Loop App</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #f4f7f6; padding: 20px; color: #333; }
        .container { max-width: 900px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }
        h1 { color: #4158D0; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f9fb; }
        .thumbnail { width: 50px; height: 50px; object-fit: cover; border-radius: 8px; }
        .btn-delete { color: #ff4757; text-decoration: none; font-weight: 600; border: 1px solid #ff4757; padding: 5px 10px; border-radius: 8px; transition: 0.3s; }
        .btn-delete:hover { background: #ff4757; color: #fff; }
        .login-box { text-align: center; padding: 50px 0; }
        .input-pass { padding: 12px; border-radius: 10px; border: 1px solid #ddd; width: 200px; margin-bottom: 10px; }
        .btn-login { padding: 12px 25px; border-radius: 10px; border: none; background: #4158D0; color: #fff; cursor: pointer; }
        .badge { padding: 4px 8px; border-radius: 5px; font-size: 11px; color: #fff; }
        .badge-video { background: #ff4757; }
        .badge-image { background: #2ed573; }
        .nav-links { margin-bottom: 20px; display: flex; justify-content: space-between; }
    </style>
</head>
<body>

<div class="container">
    <?php if (!$is_logged_in): ?>
        <div class="login-box">
            <h2>Quản trị viên</h2>
            <form method="POST">
                <input type="password" name="login_pass" class="input-pass" placeholder="Nhập mật khẩu..." required><br>
                <button type="submit" class="btn-login">Đăng nhập</button>
            </form>
        </div>
    <?php else: ?>
        <div class="nav-links">
            <a href="index.php" style="text-decoration: none; color: #4158D0;">← Quay lại Loop App</a>
            <a href="?logout=1" style="color: #888;">Đăng xuất</a>
        </div>
        
        <h1>Danh sách bài viết</h1>
        <?php if(isset($_GET['status']) && $_GET['status'] == 'deleted'): ?>
            <p style="color: green; font-weight: bold;">✅ Đã xóa bài viết thành công!</p>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>Ảnh</th>
                    <th>Tiêu đề / Tác giả</th>
                    <th>Loại</th>
                    <th>Ngày đăng</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($posts)): ?>
                    <tr><td colspan="5" style="text-align: center;">Chưa có bài viết nào.</td></tr>
                <?php else: ?>
                    <?php foreach ($posts as $p): ?>
                    <tr>
                        <td><img src="<?php echo $p['image']; ?>" class="thumbnail"></td>
                        <td>
                            <strong><?php echo $p['title']; ?></strong><br>
                            <small style="color: #888;"><?php echo $p['user']; ?></small>
                        </td>
                        <td>
                            <span class="badge <?php echo $p['type'] == 'video' ? 'badge-video' : 'badge-image'; ?>">
                                <?php echo strtoupper($p['type']); ?>
                            </span>
                        </td>
                        <td><small><?php echo $p['date']; ?></small></td>
                        <td>
                            <a href="?delete_id=<?php echo $p['id']; ?>" 
                               class="btn-delete" 
                               onclick="return confirm('Bạn có chắc chắn muốn xóa bài này không?')">Xóa</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

</body>
</html>
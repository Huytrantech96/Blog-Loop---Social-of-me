<script>
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      // Đăng ký Service Worker chỉ dành riêng cho thư mục /blog/
      navigator.serviceWorker.register('cache.js', { scope: './' })
        .then(reg => {
          console.log('🚀 Blog Cache đã kích hoạt tại phạm vi:', reg.scope);
        })
        .catch(err => {
          console.error('❌ Lỗi Service Worker Blog:', err);
        });
    });
  }
</script>
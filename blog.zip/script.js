document.addEventListener('DOMContentLoaded', () => {
    // 1. Xử lý Upload/Paste ảnh
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const base64Input = document.getElementById('image-base64');
    const previewImg = document.getElementById('image-preview');
    const previewText = document.getElementById('preview-text');

    if(dropZone) {
        dropZone.onclick = () => fileInput.click();
        
        fileInput.onchange = (e) => handleImage(e.target.files[0]);

        window.onpaste = (e) => {
            const item = e.clipboardData.items[0];
            if (item && item.type.includes('image')) handleImage(item.getAsFile());
        };
    }

    function handleImage(file) {
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            previewImg.src = e.target.result;
            previewImg.style.display = 'block';
            previewText.style.display = 'none';
            base64Input.value = e.target.result;
        };
        reader.readAsDataURL(file);
    }

    // 2. Motion: Cuộn tới đâu hiện tới đó
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) entry.target.classList.add('active');
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
});
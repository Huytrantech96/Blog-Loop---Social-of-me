<?php
/**
 * TOOL TỰ ĐỘNG CÀO VIDEO TFT/DTCL TỪ YOUTUBE VÀO LOOP APP
 * Hướng dẫn: Upload file này lên cùng thư mục với index.php và posts.json
 */

// --- CẤU HÌNH ---
$postFile = 'posts.json';
$apiKey = 'AIzaSyDchCV-qE4dtdPFohFyw9g9ihzSK2-Vrek';
$channelId = 'UC2t5bjwHdUX4vM2g8TRDq5g'; // Ví dụ ID kênh Mortdog (Có thể thay đổi)
$maxResults = 10; // Số lượng video lấy mỗi lần chạy
$userTag = '@AutoTFT'; // Tên hiển thị của bot trên ứng dụng

// 1. Kiểm tra sự tồn tại của file dữ liệu
if (!file_exists($postFile)) {
    file_put_contents($postFile, json_encode([]));
}

// 2. Lấy dữ liệu hiện tại từ file JSON
$current_data = file_get_contents($postFile);
$posts = json_decode($current_data, true);
if (!is_array($posts)) $posts = [];

// Trích xuất danh sách các video_id đã có để chống trùng lặp
$existingIds = array_column($posts, 'video_id');

// 3. Gọi API YouTube Data v3
// Sử dụng channelId để lấy video từ kênh cố định, hoặc thay bằng &q=TFT để tìm kiếm dạo
$apiUrl = "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=$channelId&type=video&order=date&maxResults=$maxResults&key=$apiKey";

// Sử dụng cURL để gọi API (an toàn và ổn định hơn file_get_contents)
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);

// Kiểm tra lỗi từ phía YouTube API
if (isset($data['error'])) {
    die("Lỗi API: " . $data['error']['message']);
}

if (!isset($data['items']) || empty($data['items'])) {
    die("Không tìm thấy video nào mới.");
}

$newCount = 0;

// 4. Lọc và xử lý video mới
foreach ($data['items'] as $item) {
    $videoId = $item['id']['videoId'];
    $title = $item['snippet']['title'];
    $description = $item['snippet']['description'];
    $thumb = "https://img.youtube.com/vi/$videoId/maxresdefault.jpg";
    
    // KIỂM TRA CHỐNG TRÙNG LẶP
    if (!in_array($videoId, $existingIds)) {
        // Tạo cấu trúc mảng giống hệt file index.php yêu cầu
        $newPost = [
            'id' => time() . rand(100, 999), // ID duy nhất dựa trên thời gian
            'type' => 'video',
            'title' => htmlspecialchars($title),
            'content' => htmlspecialchars(mb_substr($description, 0, 200)) . '...', // Cắt ngắn mô tả
            'image' => $thumb,
            'video_id' => $videoId,
            'user' => $userTag,
            'date' => date('H:i, d/m')
        ];

        // Đưa bài viết mới lên đầu mảng
        array_unshift($posts, $newPost);
        $newCount++;
    }
}

// 5. Lưu lại vào file JSON nếu có video mới
if ($newCount > 0) {
    // Lưu với định dạng JSON đẹp để dễ kiểm tra
    $jsonData = json_encode($posts, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if (file_put_contents($postFile, $jsonData)) {
        echo "<div style='font-family:sans-serif; padding:20px; background:#e1f5fe; border-radius:10px; color:#01579b;'>";
        echo "<h3>Thành công!</h3>";
        echo "Đã tìm thấy và thêm mới: <b>$newCount</b> bài viết video.<br>";
        echo "Tổng số bài viết hiện tại: " . count($posts);
        echo "<br><br><a href='index.php'>Quay lại trang chủ</a>";
        echo "</div>";
    } else {
        echo "Lỗi: Không thể ghi vào file $postFile. Hãy kiểm tra quyền (permission) của file.";
    }
} else {
    echo "<div style='font-family:sans-serif; padding:20px; background:#fff3e0; border-radius:10px; color:#e65100;'>";
    echo "Không có video mới nào được thêm. (Tất cả video lấy về đã tồn tại trên hệ thống).";
    echo "<br><br><a href='index.php'>Quay lại trang chủ</a>";
    echo "</div>";
}
?>
<?php
$musicFile = 'music.json';
if (!file_exists($musicFile)) file_put_contents($musicFile, json_encode([]));
$songs = json_decode(file_get_contents($musicFile), true);

// XỬ LÝ LƯU LINK
if (isset($_POST['action']) && $_POST['action'] == 'add_link') {
    $videoId = $_POST['video_id'];
    $title = htmlspecialchars($_POST['title']);
    
    // Kiểm tra xem bài hát đã tồn tại chưa
    $exists = false;
    foreach($songs as $s) {
        if($s['id'] == $videoId) { $exists = true; break; }
    }
    
    if(!$exists) {
        array_unshift($songs, ['id' => $videoId, 'title' => $title, 'date' => date('d/m/Y')]);
        file_put_contents($musicFile, json_encode($songs));
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'msg' => 'Bài hát này đã có trong thư viện!']);
    }
    exit();
}
?>
<?php include_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>My Playlist</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <style>
        :root { --p: #4158D0; --bg: #f8f9fb; --radius: 24px; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); margin: 0; padding: 20px; padding-bottom: 120px; }
        .card { background: #fff; padding: 20px; border-radius: var(--radius); box-shadow: 0 10px 30px rgba(0,0,0,0.05); margin-bottom: 25px; }
        .neu-input { width: 100%; padding: 16px; border-radius: 15px; border: 2px solid #f0f2f5; background: #f0f2f5; margin-bottom: 12px; font-size: 15px; box-sizing: border-box; }
        .btn-main { width: 100%; padding: 16px; border-radius: 15px; border: none; background: var(--p); color: #fff; font-weight: 700; cursor: pointer; }
        
        .song-item { background: #fff; padding: 12px; border-radius: 20px; margin-bottom: 10px; display: flex; align-items: center; gap: 12px; cursor: pointer; transition: 0.2s; border: 2px solid transparent; }
        .song-item.active { border-color: var(--p); background: #f0f4ff; }
        .song-thumb { width: 50px; height: 50px; border-radius: 12px; object-fit: cover; }
        .song-info { flex: 1; min-width: 0; }
        .song-name { font-weight: 700; font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        
        /* Player cố định bên dưới */
        .player-bar { position: fixed; bottom: 0; left: 0; right: 0; background: #fff; padding: 15px 20px; box-shadow: 0 -5px 20px rgba(0,0,0,0.05); z-index: 1000; border-radius: 25px 25px 0 0; display: none; }
        .player-bar.active { display: block; }
        #yt-frame { width: 0; height: 0; border: 0; position: absolute; }
        .player-content { display: flex; align-items: center; gap: 15px; }
        .controls { display: flex; align-items: center; gap: 20px; font-size: 24px; }
    </style>
</head>
<body>

<a href="index.php" style="text-decoration:none; color:#888; font-weight:600;">← Quay lại</a>

<div class="card">
    <h2 style="margin: 10px 0;">Thêm bài hát</h2>
    <input type="text" id="urlInput" class="neu-input" placeholder="Dán link Youtube...">
    <button id="addBtn" class="btn-main">THÊM VÀO DANH SÁCH</button>
</div>

<div id="playlist">
    <h3 style="margin-bottom: 15px;">Playlist của bạn (<?php echo count($songs); ?>)</h3>
    <?php foreach ($songs as $s): ?>
    <div class="song-item" onclick="playSong('<?php echo $s['id']; ?>', this)">
        <img class="song-thumb" src="https://img.youtube.com/vi/<?php echo $s['id']; ?>/mqdefault.jpg">
        <div class="song-info">
            <div class="song-name"><?php echo $s['title']; ?></div>
            <div style="font-size: 11px; color: #888;"><?php echo $s['date']; ?></div>
        </div>
        <div style="font-size: 18px;">▶️</div>
    </div>
    <?php endforeach; ?>
</div>

<div class="player-bar" id="playerBar">
    <div id="yt-player"></div> <div class="player-content">
        <div class="song-info">
            <div id="nowPlayingTitle" class="song-name" style="color: var(--p);">Đang phát...</div>
            <div style="font-size: 11px; color: var(--p);">Chế độ: Tự động lặp lại 🔁</div>
        </div>
        <div class="controls">
            <span onclick="togglePlay()" id="playIcon">⏸️</span>
        </div>
    </div>
</div>

<script src="https://www.youtube.com/iframe_api"></script>
<script>
    let player;
    let currentVideoId = '';

    function onYouTubeIframeAPIReady() {
        player = new YT.Player('yt-player', {
            height: '0',
            width: '0',
            videoId: '',
            playerVars: { 
                'autoplay': 1, 
                'loop': 1, 
                'playlist': '', // Sẽ cập nhật khi play
                'controls': 0 
            },
            events: {
                'onStateChange': onPlayerStateChange
            }
        });
    }

    function onPlayerStateChange(event) {
        // Nếu bài hát kết thúc (YT.PlayerState.ENDED = 0)
        if (event.data === YT.PlayerState.ENDED) {
            player.playVideo(); // Tự động lặp lại
        }
    }

    function playSong(id, el) {
        currentVideoId = id;
        document.querySelectorAll('.song-item').forEach(i => i.classList.remove('active'));
        el.classList.add('active');
        
        const title = el.querySelector('.song-name').innerText;
        document.getElementById('nowPlayingTitle').innerText = title;
        document.getElementById('playerBar').classList.add('active');
        
        player.loadVideoById(id);
        // Để lặp lại bài hiện tại trong YT API:
        player.setLoop(true); 
        document.getElementById('playIcon').innerText = '⏸️';
    }

    function togglePlay() {
        const state = player.getPlayerState();
        if (state === 1) { // 1 là đang phát
            player.pauseVideo();
            document.getElementById('playIcon').innerText = '▶️';
        } else {
            player.playVideo();
            document.getElementById('playIcon').innerText = '⏸️';
        }
    }

    // XỬ LÝ THÊM LINK
    document.getElementById('addBtn').addEventListener('click', async function() {
        const url = document.getElementById('urlInput').value.trim();
        const vId = getID(url);
        if (!vId) return alert("Link không đúng!");

        this.disabled = true;
        this.innerText = "Đang lấy thông tin...";

        // Lấy tiêu đề video qua link oembed của YT (không cần API key nặng nề)
        try {
            const response = await fetch(`https://noembed.com/embed?url=https://www.youtube.com/watch?v=${vId}`);
            const data = await response.json();
            
            const fd = new FormData();
            fd.append('action', 'add_link');
            fd.append('video_id', vId);
            fd.append('title', data.title || "Video Youtube");

            const saveResp = await fetch('taimp3.php', { method: 'POST', body: fd });
            const result = await saveResp.json();
            
            if(result.status === 'success') {
                location.reload();
            } else {
                alert(result.msg);
            }
        } catch (e) {
            alert("Lỗi kết nối!");
        } finally {
            this.disabled = false;
            this.innerText = "THÊM VÀO DANH SÁCH";
        }
    });

    function getID(url) {
        const reg = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
        const match = url.match(reg);
        return (match && match[2].length === 11) ? match[2] : null;
    }
</script>
</body>
</html>
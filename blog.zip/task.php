<?php
date_default_timezone_set('Asia/Ho_Chi_Minh');
$taskFile = 'tasks.json';
$currentFile = basename(__FILE__);

if (!file_exists($taskFile)) file_put_contents($taskFile, json_encode([]));
$tasks = json_decode(file_get_contents($taskFile), true) ?? [];

// --- XỬ LÝ API ---
if (isset($_GET['action'])) {
    $id = $_GET['id'] ?? '';
    if ($_GET['action'] === 'add') {
        $tasks[] = ['id' => time(), 'time' => $_GET['time'], 'name' => $_GET['name'], 'status' => 'pending'];
    } elseif ($_GET['action'] === 'edit') {
        foreach ($tasks as &$t) if ((string)$t['id'] === (string)$id) { $t['name'] = $_GET['name']; $t['time'] = $_GET['time']; }
    } elseif ($_GET['action'] === 'toggle') {
        foreach ($tasks as &$t) if ((string)$t['id'] === (string)$id) $t['status'] = ($t['status'] === 'done' ? 'pending' : 'done');
    } elseif ($_GET['action'] === 'delete') {
        $tasks = array_values(array_filter($tasks, fn($t) => (string)$t['id'] !== (string)$id));
    }
    file_put_contents($taskFile, json_encode(array_values($tasks), JSON_UNESCAPED_UNICODE));
    echo "ok"; exit;
}

usort($tasks, fn($a, $b) => strcmp($a['time'], $b['time']));
$curr = date('H:i');
$doneCount = count(array_filter($tasks, fn($t) => $t['status'] === 'done'));
$totalCount = count($tasks);
$percent = $totalCount > 0 ? floor(($doneCount / $totalCount) * 100) : 0;
?>
<?php include_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Tasks - Playlist Style</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <style>
        :root { --p: #4158D0; --bg: #f8f9fb; --radius: 24px; --red: #ff3b30; --green: #34c759; }
        * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; outline: none; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); margin: 0; padding: 20px; padding-bottom: 120px; color: #1a1a1a; }
        
        /* Header */
        .back-link { text-decoration: none; color: #888; font-weight: 600; font-size: 14px; display: inline-block; margin-bottom: 20px; }

        /* Card Main */
        .card { background: #fff; padding: 25px; border-radius: var(--radius); box-shadow: 0 10px 30px rgba(0,0,0,0.05); margin-bottom: 25px; }
        .btn-main { width: 100%; padding: 16px; border-radius: 15px; border: none; background: var(--p); color: #fff; font-weight: 700; cursor: pointer; transition: 0.2s; font-family: inherit; }
        .btn-main:active { transform: scale(0.98); }

        /* Task Item */
        .song-item { 
            background: #fff; padding: 16px; border-radius: 20px; margin-bottom: 12px; 
            display: flex; align-items: center; gap: 15px; cursor: pointer; 
            transition: 0.3s; border: 2px solid transparent; box-shadow: 0 4px 15px rgba(0,0,0,0.02);
            position: relative; overflow: hidden;
        }
        .song-item:active { transform: scale(0.97); background: #f9f9f9; }
        
        /* Trạng thái đã xong */
        .song-item.done { opacity: 0.7; background: #f4f4f4; }
        .song-item.done .song-thumb { background: var(--green); color: white; border-color: var(--green); }
        .song-item.done .song-name { text-decoration: line-through; color: #888; }

        .song-thumb { 
            width: 54px; height: 54px; border-radius: 16px; 
            background: #f0f2f5; display: flex; align-items: center; 
            justify-content: center; font-weight: 800; color: var(--p); font-size: 12px;
            border: 2px solid #eee; flex-shrink: 0; transition: 0.3s;
        }

        .song-info { flex: 1; min-width: 0; }
        .song-name { font-weight: 700; font-size: 15px; margin-bottom: 4px; display: block; word-wrap: break-word; }
        
        .controls { display: flex; gap: 12px; padding-left: 10px; }
        .btn-action { font-size: 18px; color: #bbb; padding: 5px; cursor: pointer; z-index: 10; }

        /* Player bar tiến độ */
        .player-bar { 
            position: fixed; bottom: 0; left: 0; right: 0; background: #fff; 
            padding: 15px 25px 25px 25px; box-shadow: 0 -10px 40px rgba(0,0,0,0.1); 
            z-index: 1000; border-radius: 30px 30px 0 0; 
        }
        .progress-container { width: 100%; height: 6px; background: #f0f2f5; border-radius: 10px; margin-top: 10px; overflow: hidden; }
        .progress-bar { height: 100%; background: var(--p); border-radius: 10px; transition: 0.8s cubic-bezier(0.17, 0.67, 0.83, 0.67); }

        /* Overlay */
        .overlay { 
            position: fixed; inset: 0; background: rgba(255,255,255,0.98); 
            z-index: 2000; display: none; padding: 40px 25px; backdrop-filter: blur(15px);
        }
        .overlay.active { display: block; animation: slideUp 0.3s ease; }
        @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
        
        .neu-input { width: 100%; padding: 18px; border-radius: 18px; border: 2px solid #f0f2f5; background: #f0f2f5; margin-bottom: 15px; font-size: 16px; font-family: inherit; }
        .close-btn { font-size: 32px; float: right; cursor: pointer; color: #000; font-weight: 300; }
    </style>
</head>

<body>

<a href="index.php" class="back-link">← Quay lại trang chủ</a>

<div class="card">
    <h2 style="margin: 0 0 5px 0; font-weight: 800; font-size: 24px;">Hôm nay</h2>
    <p style="margin: 0 0 20px 0; color: #888; font-size: 14px;">Bạn có <?= $totalCount ?> nhiệm vụ cần xử lý</p>
    <button class="btn-main" onclick="openModal()">+ THÊM NHIỆM VỤ MỚI</button>
</div>

<div id="playlist">
    <?php foreach ($tasks as $t): 
        $isOver = ($t['status'] === 'pending' && $t['time'] < $curr);
    ?>
    <div class="song-item <?= $t['status']==='done'?'done':'' ?>" id="task-<?= $t['id'] ?>">
        <div class="song-thumb" onclick="toggleTask('<?= $t['id'] ?>')">
            <?= $t['status']==='done' ? '✓' : $t['time'] ?>
        </div>
        
        <div class="song-info" onclick="toggleTask('<?= $t['id'] ?>')">
            <span class="song-name" id="name-<?= $t['id'] ?>"><?= htmlspecialchars($t['name']) ?></span>
            <div style="font-size: 11px; color: <?= $isOver && $t['status']!=='done' ? 'var(--red)' : '#aaa' ?>;">
                <?= $t['status']==='done' ? 'Đã hoàn thành' : ($isOver ? '⚠️ Quá hạn' : '🕒 Hạn: '.$t['time']) ?>
            </div>
            <span id="time-<?= $t['id'] ?>" style="display:none"><?= $t['time'] ?></span>
        </div>

        <div class="controls">
            <span class="btn-action" onclick="openEdit('<?= $t['id'] ?>')">✎</span>
            <span class="btn-action" onclick="deleteTask('<?= $t['id'] ?>')">✕</span>
        </div>
    </div>
    <?php endforeach; ?>
    
    <?php if($totalCount == 0): ?>
        <div style="text-align: center; padding: 40px; color: #ccc;">
            <div style="font-size: 50px; margin-bottom: 10px;">☕</div>
            <p>Chưa có nhiệm vụ nào!</p>
        </div>
    <?php endif; ?>
</div>

<div class="player-bar">
    <div style="display: flex; justify-content: space-between; align-items: flex-end;">
        <div>
            <div style="font-weight: 800; font-size: 16px; color: var(--p);">Hoàn thành <?= $percent ?>%</div>
            <div style="font-size: 12px; color: #888; margin-top: 2px;"><?= $doneCount ?> trên tổng số <?= $totalCount ?> bài viết</div>
        </div>
        <div style="font-size: 24px;">📊</div>
    </div>
    <div class="progress-container">
        <div class="progress-bar" style="width: <?= $percent ?>%"></div>
    </div>
</div>

<div id="taskOverlay" class="overlay">
    <span class="close-btn" onclick="closeModal()">×</span>
    <h2 id="modalTitle" style="font-weight: 800; margin-top: 0; margin-bottom: 30px;">Nhiệm vụ mới</h2>
    
    <input type="hidden" id="edit-id">
    
    <label style="font-size: 12px; font-weight: 800; color: #888; display: block; margin: 0 0 8px 5px;">THỜI GIAN</label>
    <input type="time" id="task-time" class="neu-input" value="<?= date('H:i') ?>">
    
    <label style="font-size: 12px; font-weight: 800; color: #888; display: block; margin: 15px 0 8px 5px;">NỘI DUNG</label>
    <textarea id="task-name" class="neu-input" rows="4" placeholder="Nhập việc cần làm..."></textarea>
    
    <button class="btn-main" onclick="handleSave()" style="margin-top: 10px; height: 65px; font-size: 16px;">LƯU NHIỆM VỤ</button>
</div>

<script>
    const API_URL = '<?= $currentFile ?>';

    function openModal() {
        document.getElementById('modalTitle').innerText = "Nhiệm vụ mới";
        document.getElementById('edit-id').value = "";
        document.getElementById('task-name').value = "";
        document.getElementById('taskOverlay').classList.add('active');
    }

    function closeModal() {
        document.getElementById('taskOverlay').classList.remove('active');
    }

    function openEdit(id) {
        event.stopPropagation(); // Ngăn chặn việc tick done khi bấm nút sửa
        document.getElementById('modalTitle').innerText = "Chỉnh sửa";
        document.getElementById('edit-id').value = id;
        document.getElementById('task-name').value = document.getElementById('name-'+id).innerText;
        document.getElementById('task-time').value = document.getElementById('time-'+id).innerText;
        document.getElementById('taskOverlay').classList.add('active');
    }

    async function handleSave() {
        const id = document.getElementById('edit-id').value;
        const name = document.getElementById('task-name').value.trim();
        const time = document.getElementById('task-time').value;
        if(!name) return alert("Vui lòng nhập nội dung!");

        let action = id ? `action=edit&id=${id}` : `action=add`;
        const res = await fetch(`${API_URL}?${action}&name=${encodeURIComponent(name)}&time=${time}`);
        if(await res.text() === 'ok') location.reload();
    }

    async function toggleTask(id) {
        // Hiệu ứng rung nhẹ nếu máy hỗ trợ
        if (navigator.vibrate) navigator.vibrate(10);
        
        const res = await fetch(`${API_URL}?action=toggle&id=${id}`);
        if(await res.text() === 'ok') location.reload();
    }

    async function deleteTask(id) {
        event.stopPropagation(); // Ngăn chặn tick done
        if(confirm('Xóa nhiệm vụ này?')) {
            const res = await fetch(`${API_URL}?action=delete&id=${id}`);
            if(await res.text() === 'ok') location.reload();
        }
    }
</script>

</body>
</html>